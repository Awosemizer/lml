const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C4x0dX0_.js","./index-BadbNoey.js","./index-gjyEgGVR.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BadbNoey.js";const _=r("Share",{web:()=>t(()=>import("./web-C4x0dX0_.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
