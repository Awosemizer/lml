const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Q79TikfG.js","./index-9hd7vqhF.js","./index-Bs4qQz81.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-9hd7vqhF.js";const _=r("Share",{web:()=>t(()=>import("./web-Q79TikfG.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
