const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-E8SCu0tT.js","./index-DVecNvic.js","./index-sdTZxn0v.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DVecNvic.js";const _=r("Share",{web:()=>t(()=>import("./web-E8SCu0tT.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
