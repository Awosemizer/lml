const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Ct7gbRB7.js","./index-Drr-RFzF.js","./index-C4MvwLQP.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Drr-RFzF.js";const _=r("Share",{web:()=>t(()=>import("./web-Ct7gbRB7.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
