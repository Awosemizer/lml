const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BMfUisWV.js","./index-DuIbHQyF.js","./index-D_OWetdk.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DuIbHQyF.js";const _=r("Share",{web:()=>t(()=>import("./web-BMfUisWV.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
