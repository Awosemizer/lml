const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C7yxkncn.js","./index-BTWQ9UsR.js","./index-BWBmyMWN.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BTWQ9UsR.js";const _=r("Share",{web:()=>t(()=>import("./web-C7yxkncn.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
