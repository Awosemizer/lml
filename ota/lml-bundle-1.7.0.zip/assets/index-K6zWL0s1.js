const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BHeUBiHw.js","./index-3I0QuL8m.js","./index-Jobycgij.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-3I0QuL8m.js";const _=r("Share",{web:()=>t(()=>import("./web-BHeUBiHw.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
