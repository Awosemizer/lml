const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BNLLs15-.js","./index-DVy_dK7e.js","./index-EicLR2W-.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DVy_dK7e.js";const _=r("Share",{web:()=>t(()=>import("./web-BNLLs15-.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
