const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BNIJqeCU.js","./index-G9_v8DhL.js","./index-DmqwL89u.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-G9_v8DhL.js";const _=r("Share",{web:()=>t(()=>import("./web-BNIJqeCU.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
