const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DvMAq2_a.js","./index-DgYdudeV.js","./index-K6OgCm9e.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DgYdudeV.js";const _=r("Share",{web:()=>t(()=>import("./web-DvMAq2_a.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
