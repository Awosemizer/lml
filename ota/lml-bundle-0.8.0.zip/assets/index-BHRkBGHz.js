const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DksOl_gG.js","./index-B43kVSfT.js","./index-CluZm3AK.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-B43kVSfT.js";const _=r("Share",{web:()=>t(()=>import("./web-DksOl_gG.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
