const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BlkGfh8p.js","./index-D1OpEEtX.js","./index-DqNpxWfu.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D1OpEEtX.js";const _=r("Share",{web:()=>t(()=>import("./web-BlkGfh8p.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
