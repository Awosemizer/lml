const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DHOoXycm.js","./index-BelQzE7_.js","./index-BwOqQ0bO.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BelQzE7_.js";const _=r("Share",{web:()=>t(()=>import("./web-DHOoXycm.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
