const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DTmudm2_.js","./index-j7TH2YkV.js","./index-BcP-7qHi.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-j7TH2YkV.js";const _=r("Share",{web:()=>t(()=>import("./web-DTmudm2_.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
