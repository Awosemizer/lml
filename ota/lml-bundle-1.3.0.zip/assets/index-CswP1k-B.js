const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C6lOLq7w.js","./index-CcbPSDy1.js","./index-BpZolOD3.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CcbPSDy1.js";const _=r("Share",{web:()=>t(()=>import("./web-C6lOLq7w.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
